import React from 'react';
import './App.css';
import FeatureTable from './components/Table/FeaturesTable';

function App() {
  return (
    <div className="App">
      <FeatureTable />
    </div>
  );
}

export default App;
